package com.xdnose.muerte;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.minecraft.network.packet.s2c.play.PlaySoundS2CPacket;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;

public class MuerteMod implements ModInitializer {

    public static final String MOD_ID = "xdnose_muerte";

    // Texto del chat (se escribe despues del nombre del jugador)
    private static final String MENSAJE = " Su sangre a llegado a su punto limite....";

    // Volumen del paquete. Si es mayor que 1.0 el sonido llega mas lejos.
    private static final float VOLUMEN = 1.0f;

    @Override
    public void onInitialize() {
        // Entrada "directa": no hace falta registrar el sonido; el cliente lo busca en sounds.json
        RegistryEntry<SoundEvent> sonido =
                RegistryEntry.of(SoundEvent.of(Identifier.of(MOD_ID, "muerte")));

        ServerLivingEntityEvents.AFTER_DEATH.register((entity, damageSource) -> {
            if (!(entity instanceof ServerPlayerEntity muerto)) {
                return;
            }
            MinecraftServer server = muerto.getServer();
            if (server == null) {
                return;
            }

            // 1) Mensaje rojo en el chat para todos
            Text mensaje = Text.literal(muerto.getName().getString() + MENSAJE)
                    .formatted(Formatting.RED);
            server.getPlayerManager().broadcast(mensaje, false);

            // 2) Sonido en el lugar donde murio, enviado a TODOS los jugadores
            //    (asi Sound Physics puede aplicar eco / oclusion segun el lugar)
            long seed = muerto.getRandom().nextLong();
            for (ServerPlayerEntity jugador : server.getPlayerManager().getPlayerList()) {
                jugador.networkHandler.sendPacket(new PlaySoundS2CPacket(
                        sonido,
                        SoundCategory.MASTER,
                        muerto.getX(), muerto.getY(), muerto.getZ(),
                        VOLUMEN, 1.0f, seed));
            }
        });
    }
}
